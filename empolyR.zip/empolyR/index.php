<?php 
include 'header.php'; 
include "conflit.php";
include "Database.php";
?>

<?php 
 $db = new Database();//database class er object
 $query = "SELECT * FROM table_1";
 $read = $db->select($query);//use for read
?>

<?php 
if(isset($_GET['mas'])){
 echo "<span style='color:green'>".$_GET['mas']."</span>";
}
?>

<table class="tblone">
<tr>
 <th width="10%">Serial</th>
 <th width="35%">Name</th>
 <th width="25%">Email</th>
 <th width="15%">Skill</th>
 <th width="15%">Action</th>
 <th width="15%">Action</th>
</tr>
<?php if($read){?>
<?php 
$i=1;
while($row = $read->fetch_assoc()){
?>
<tr>
 <td><?php echo $i++ ?></td>
 <td><?php echo $row['name']; ?></td>
 <td><?php echo $row['email']; ?></td>
 <td><?php echo $row['skill']; ?></td>
 <td><a href="update.php?ID=<?php echo urlencode($row['ID']); ?>">
  Edit</a></td>
  <td><a href="update.php?ID=<?php echo urlencode($row['ID']); ?>">
  Delete</a></td>
</tr>


<?php } ?>
<?php } else { ?>
<p>Data is not available !!</p>
<?php } ?>
</table>
<a href="create.php">Create</a>