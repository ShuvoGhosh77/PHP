<?php
Class Database{
 public $host   = DB_HOST;
 public $user   = DB_USER;
 public $pass   = DB_PASS;
 public $dbname = DB_NAME;
 
 
 public $link;
 public $error;
 //Create Constractor for Database Class and give the method
 public function __construct(){
  $this->connectDB();
 }//ekhn jei kan thekei Database class er object banai na keno private function connectDB() ei connection ta load hbe//
//method Create
private function connectDB(){
 $this->link = new mysqli($this->host, $this->user, $this->pass, 
  $this->dbname);
 if(!$this->link){
   $this->error ="Connection fail".$this->link->connect_error;
  return false;
 }
 }
 
// Select or Read data
public function select($query){
  $result = $this->link->query($query) or 
   die($this->link->error.__LINE__);
  if($result->num_rows > 0){
    return $result;
  } else {
    return false;
  }
 }
 // Insert data
public function insert($query){
 $insert_row = $this->link->query($query) or die($this->link->error.__LINE__);//query is mysql er function must write here//
 if($insert_row){
   header ("Location:index.php?mas= ".urlencode('Data insert sucessfull'));//if we want data insert er pre home page or another page a cle jabe tai ei condition deoya hoyeche//
   exit();
 } else {
   die("error:(".$this->link->errno.")".$this->link->error);//show spacipic line error use errno dilding function//
  }
 }
 
 // update data
public function update($query){
 $update_row = $this->link->query($query) or die($this->link->error.__LINE__);//query is mysql er function must write here//
 if(update_row){
   header ("Location:index.php?mas= ".urlencode('Data updated sucessfull'));//if we want data insert er pre home page or another page a cle jabe tai ei condition deoya hoyeche//
   exit();
 } else {
   die("error:(".$this->link->errno.")".$this->link->error);//show spacipic line error use errno dilding function//
  }
 }
 // Delete data
public function Delete($query){
 $Delete_row = $this->link->query($query) or die($this->link->error.__LINE__);//query is mysql er function must write here//
 if(Delete_row){
   header ("Location:index.php?mas= ".urlencode('Data Deleted sucessfull'));//if we want data insert er pre home page or another page a cle jabe tai ei condition deoya hoyeche//
   exit();
 } else {
   die("error:(".$this->link->errno.")".$this->link->error);//show spacipic line error use errno dilding function//
  }
 }
}