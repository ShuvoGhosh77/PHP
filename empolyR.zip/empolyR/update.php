<?php 
include 'header.php'; 
include "conflit.php";
include "Database.php";
?>
<?php 
 $ID= $_GET['ID'];
 $db = new Database();
 $query = "SELECT * FROM table_1 WHERE ID=$ID";
 $getData = $db->select($query)->fetch_assoc();
 
if(isset($_POST['submit'])){
 $name  = mysqli_real_escape_string($db->link, $_POST['name']);
 $email = mysqli_real_escape_string($db->link, $_POST['email']);
 $skill = mysqli_real_escape_string($db->link, $_POST['skill']);
 if($name == '' || $email == '' || $skill == ''){
  $error = "Field must not be Empty !!";
 } else {
  $query = "UPDATE table_1
  SET
  name  = '$name',
  email = '$email',
  skill = '$skill'
  WHERE ID = $ID";
  $update = $db->update($query);
 }
}
?>
<?php
 if(isset($_POST['Delete'])){
	 $query = "DELETE FROM table_1 WHERE ID=$ID";
	 $Deletedata= $db->Delete($query);
 }

?>
<?php 
if(isset($error)){
 echo "<span style='color:red'>".$error."</span>";
}
?>
<form action="update.php?ID=<?php echo $ID;?>" method="post">
<table>
 <tr>
  <td>Name</td>
  <td><input type="text" name="name" 
  value="<?php echo $getData['name'] ?>"/></td>
 </tr>
 <tr>
  <td>Email</td>
  <td><input type="text" name="email"
  value="<?php echo $getData['email'] ?>"/></td>
 </tr>

 <tr>
  <td>Skill</td>
  <td><input type="text" name="skill" 
  value="<?php echo $getData['skill'] ?>"/></td>
 </tr>
 <tr>
  <td></td>
  <td>
  <input type="submit" name="submit" value="Update"/>
  <input type="reset" Value="Cancel" />
  <input type="submit" name="Delete" Value="Delete" />
  </td>
 </tr>

</table>
</form>
<a href="index.php">Go Back</a>